""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""
	 
# SkPolyFit.py:  Polynomial regression with sklearn

import numpy as np; import matplotlib.pyplot as plt
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
import numpy as np

poly = PolynomialFeatures(degree=6, include_bias=False)
mA = np.array([1, 2, 3, 4, 5, 6, 7])       # Mass number
poly_features = poly.fit_transform(mA.reshape(-1, 1))  
B = [0.0140,1.1520,2.8235,1.8150,1.3871,0.9465,1.2971]  # BE/N
poly_reg_model = LinearRegression()
poly_reg_model.fit(poly_features, B)
b_predicted = poly_reg_model.predict(poly_features)
intcp = poly_reg_model.intercept_,           # Poly's intercept
print(intcp)
coefs = poly_reg_model.coef_              # Poly's coefficients
print(coefs) 

def predict_y_value(x):
    y = -1.91 + 1.72*x + 0.288*x**2 - 0.182*x**3 + 0.016*x**4
    return y
def pred_y_val(x):
    y = intcp + coefs[0]*x + coefs[1]*x*x + coefs[2]*x**3
    return y
xx = np.linspace(1,7,50)                      # Plot polynomial
yy = predict_y_value(xx)
y4 = pred_y_val(xx)
fig, ax = plt.subplots()
ax.scatter(mA,B)                                  # Plot points
plt.xlabel('Mass Number')
plt.ylabel('Binding Energy per nucleon')
plt.plot(xx, yy, c = "red", label="3rd degree poly")
plt.legend()
plt.plot(xx, y4, label ="4th degree poly")
plt.legend()
plt.show()