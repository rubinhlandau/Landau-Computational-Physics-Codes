""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""
    
# WormHole.py: Derivative for Ellis Wormhole via Sympy 

from sympy import *

L, x, M, rho, a, r, I ,lp= symbols('L x M rho a r I lp')
x = (2*L-a)/(pi*M)
r = rho + M*(x*atan(x) -log(1+x*x)/2)
p = diff(r,L)
print(p)
n = simplify(p)
print(n)
v = integrate(sqrt(1-n*n),(L,0,lp))
print("integral",v) 