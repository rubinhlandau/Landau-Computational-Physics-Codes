""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""
	 
# CVision.py: Image processing with OpenCV

import numpy as np; import cv2 as cv
import matplotlib.pyplot as plt

image = cv.imread("c:/ripe2.jpg")                      # Read image
fig,ax = plt.subplots()
hist = cv.calcHist([image], [0], None, [256], [0,256])   # 3 colors
ax.plot(hist, color ='b', linestyle='-')
hist = cv.calcHist([image],[1], None,[256], [0,256])
ax.plot(hist, color ='g',linestyle='-.')
hist = cv.calcHist([image], [2], None, [256], [0,256])
ax.plot(hist, color ='r', linestyle=':')
plt.legend(["blue", "green", "red"])
plt.title("ripe2")
plt.xlim([0,256])
plt.ylim([0,150000])
plt.show()