""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""

# MatPlot2figs.py: plot of 2 subplots on 1 fig, 2 separate figs

from pylab import *                           
Xmin = -5.0; Xmax =  5.0; Npoints= 500
DelX= (Xmax-Xmin)/Npoints                             
x1 = arange(Xmin, Xmax, DelX)                        
x2 = arange(Xmin, Xmax, DelX/20)           
y1 =  -sin(x1)*cos(x1*x1)                          # Function 1
y2 =   exp(-x2/4.)*sin(x2)                         # Function 2
print("\n Now plotting, look for Figures 1 & 2 on desktop")                                                                                   
figure(1)          
subplot(2,1,1)                             # Subplot in 1st fig
plot(x1, y1, 'r', lw=2) 
xlabel('x');  ylabel( 'f(x)' ); title( '$-\sin(x)*\cos(x^2)$')
grid(True)                                          # Form grid
subplot(2,1,2)                           # 2nd subplot, 1st fig
plot(x2, y2, '-', lw=2)
xlabel('x')                                       # Axes labels
ylabel( 'f(x)' )
title( 'exp(-x/4)*sin(x)' ) 
figure(2)   
subplot(2,1,1)                           # 1st subplot, 2nd fig 
plot(x1, y1*y1, 'r', lw=2) 
xlabel('x'); ylabel('f(x');  title('$\sin^2(x)*\cos^2(x^2)$')
subplot(2,1,2)                            # 2nd subplot, 2nd fig 
plot(x2, y2*y2, '-', lw=2)
xlabel('x'); ylabel('f(x)');  title('$\exp(-x/2)*\sin^2(x)$') 
grid(True)
show()                   