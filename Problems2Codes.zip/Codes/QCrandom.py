""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""
	 
# QCrandom.py: Quantum Random Numbers 

import cirq; import numpy as np; import matplotlib.pyplot as plt
nrep = 9                           # No. bits per random number
ntimes = 200                           # No. of random decimals 
def randomgenerate():
    qubit = cirq.LineQubit(0)                              # q0
    circ = cirq.Circuit()                      # Create circuit
    circ.append([cirq.H(qubit), cirq.measure(qubit, key="z")])
    simu = cirq.Simulator()                  # Simulate circuit
    res = simu.run(circ,repetitions=nrep)
    rr = res.measurements["z"]
    def stringofbits(bits):                   # Form binary no.
        return  ''.join('1' if e else '0' for e in bits)  
    strbits = stringofbits(rr)                
    integerval =int(strbits,2)             # Convert to decimal
    return strbits, integerval
aleatx = []
aleaty = []
intrbts,value = randomgenerate()
for i in range(1,ntimes):                    # (x,y)'s for plot
    intrbts,value = randomgenerate()
    x = value
    aleatx.append(x)
    stri,value = randomgenerate()
    y = value
    aleaty.append(y)
plt.xlabel("x")
plt.ylabel("y")
plt.title("Quantum Random (x,y)'s")
plt.scatter(aleatx,aleaty, color="black")  
plt.show()