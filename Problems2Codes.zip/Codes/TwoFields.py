""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""
   
# TwoFields.py:  Motion of charges in 2 frames via Field TF  

from vpython import *
scene = canvas(width=700, height=300, range=1,
              title="Frame S with moving charges")
graf = curve(color=color.red)
r1 = vector(-.9,.2,0)  
charge = sphere(pos=r1,color=color.red, radius=.02,make_trail=True)
r2 = vector(-.9,-.2,0)  
charge2 = sphere(pos=r2,color=color.red,radius=.02,make_trail=True)
scene2 = canvas(y=300,width=700,height=300, range=1,
               title= "Frame S' with velocity u to the right")
r1p = r1
r2p = r2
charge3 = sphere(color=color.red, radius=.02,
	make_trail=True,display=scene2)
charge4 = sphere(color=color.red, radius=.02
	,make_trail=True,display=scene2)
mu0 = 1                                                 # Vacuum   
e0 = 1                                                  # Vacuum
q1 = 2                      
q2 = 2                     
m0 = 50.                    
dt = 0.01                   
beta = 0.4                                                # v/c 
gamma = 1/sqrt(1-beta**2)   
m = m0*gamma
dtp = dt*gamma                                 # Time step in O'
facv = 1./(1.-beta**2)      
ux = beta                                       # V of O' wrt O  

def EBtransform(E,B):         
    Exp = E.x                 
    Eyp = gamma*(E.y-ux*B.z)
    Ezp = gamma*(E.z+ux*B.y)
    Bxp = B.x
    Byp = gamma*(B.y+ux*E.x)
    Bzp = gamma*(B.z-ux*E.y)
    Ep = vector(Exp,Eyp,Ezp)
    Bp = vector(Bxp,Byp,Bzp)
    return Ep,Bp                      
def EulerPlusTF():                       # Euler ODE + Lorentz TF
    u = vector(0.4,0,0)                            # V of q1 in O
    r1 = vector(-.9,.2,0)    
    r2 = vector(-.9,-.2,0)   
    v2 = u                   
    v1 = u                   
    fcv1 = 1./(1-u.x*mag(v1))  
    v1xp = (v1.x-u.x)*fcv1     
    v1yp = v1.y*fcv1/gamma
    v1zp = v1.z*fcv1/gamma
    v1p = vector(v1xp,v1yp,v1zp)
    v2p = v1p
    r1p = r1                                       # Initial r's
    r2p = r2              
    for i in range (0,300):    
       rate(100)               
       rr1 = r2-r1                                  #  q2 wrt r1
       rr2 = -rr1              
       rr = mag(rr1)           
       B1 =  q1*cross(v1,rr1)/(4*pi *rr**3)            # B  at 2
       B2 =  q2*cross(v2,rr2)/(4*pi *rr**3)             # B at 1
       E1 = q1*rr1/(4*pi*rr**3)                    # E of 1 at 2
       E2 = q2*rr2/(4*pi*rr**3)                    # E of 2 at 1
       E1p,B1p = EBtransform(E1,B1)
       E2p,B2p = EBtransform(E2,B2)
       ux = u.x                       
       FB1 = cross(v2,B1)                             # B F on 2
       FB2 = cross(v1,B2)         
       F2 = q1*(E2+FB2)                         # Lorentz F on 2
       F1 = q2*(E1+FB1)           
       FB1p = cross(v2p,B1p)                          # B F on 1
       FB2p = cross(v1p,B2p)      
       F1p = q2*(E1p+FB1p)                # Lorentz F on 2 in O'
       F2p = q1*(E2p+FB2p)        
       a2 = F1/m0                                 # a of 2 in O
       a1 = F2/m0                 
       a2p = F1p/m                                # a of 2 in O'
       a1p = F2p/m                
       v2 = v2+a1*dt                              # v of 1 in O
       v1 = v1+a2*dt              
       x1 = r1.x                  
       r1 = r1+v2*dt
       x2 = r1.x                  
       dx = x2-x1
       dtp = (dt-dx*u.x)*gamma                # time step in O'
       r2 = r2+v1*dt
       v1p = v1p+a2p*dtp                       # velocity in O'
       v2p = v2p+a1p*dtp          
       r1p = r1p+v2p*dtp
       r2p = r2p+v1p*dtp
       charge3.pos = r1p      
       charge4.pos = r2p
       charge2.pos = r2
       charge.pos = r1
EulerPlusTF()                                     # Animation