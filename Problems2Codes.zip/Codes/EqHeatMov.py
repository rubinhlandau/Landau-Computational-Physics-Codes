""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""
   
# EqHeatMov.py: Matplotlib, animated heat eqn via finite diffs

from numpy import *; import matplotlib.animation as animation
import numpy as np, matplotlib.pyplot as plt

Nx = 101;   Dx = 0.01414;   Dt = 0.6                                                                 
kappa = 210.;  sph = 900.; rho = 2700.                                         
cons = kappa/(sph*rho)*Dt/(Dx*Dx)          # For algorthim
T = np.zeros((Nx, 2), float)              # T, 1st 2 times

def init():
   for ix in range (1, Nx - 1):   T[ix, 0] = 100.0      # T(0)
   T[0, 0] = 0.0;  T[0, 1] = 0.               # Bar ends (0)    
   T[Nx - 1, 0] = 0.;  T[Nx - 1, 1] = 0.0
init()
k = range(0,Nx)
fig = plt.figure()        
# select axis; 111: only one plot, x,y, scales given
ax = fig.add_subplot(111, autoscale_on=False, xlim=(-5, 105), 
	ylim=(-5, 110.0))
ax.grid()                                       
plt.ylabel("Temperature")      		 
plt.title("Cooling of a bar")
line, = ax.plot(k, T[k,0],"r", lw=2)      
plt.plot([1,99],[0,0],"r",lw=10)          
plt.text(45,5,'bar',fontsize=20)         
 
def animate(dum):                    # Dummy num for animation
   for ix in range (1, Nx-1):    
      T[ix, 1] = T[ix, 0] + cons*(T[ix+1,0]+T[ix-1,0]-2*T[ix, 0])
   line.set_data(k,T[k,1] )     
   for ix in range (1, Nx-1):  T[ix,0] = T[ix,1]  # 100 positions  
   return line,            
ani = animation.FuncAnimation(fig, animate,1)            # 1=dummy
plt.show()