""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""
	 
# QFTrect.py:  3 Qubit QFT of Rect Function 

import cirq; import numpy as np; import matplotlib.pyplot as plt

def qft_steps(qubits):
    steps = []
    n = len(qubits)
    for i in range(n):
        steps.append([cirq.H(qubits[i])])
        for j in range(i+1, n):
           angle = np.pi/2**(j-i)
           steps.append([cirq.CZ(qubits[j],qubits[i])**(angle/np.pi)])
    for i in range(n // 2):           # SWAP contol bit order
        steps.append([cirq.SWAP(qubits[i],qubits[n-i-1])])
    return steps
    
def encode_rect_state(rect_vector):
    norm = np.linalg.norm(rect_vector)
    return np.array(rect_vector)/norm
    
rect_vector = [ 0, 0, 1, 1, 1, 1, 0, 0]
state = encode_rect_state(rect_vector)
qubits = cirq.LineQubit.range(3)                  # Create qubits
steps = qft_steps(qubits)
simulator = cirq.Simulator()               # Initialize simulator
circuit = cirq.Circuit()                        # Initial circuit
circuit.append(cirq.StatePreparationChannel(state).on(*qubits))
intermediate_states=[simulator.simulate(circuit).final_state_vector]
for step in steps:
    circuit.append(step)
    result = simulator.simulate(circuit)
    intermediate_states.append(result.final_state_vector)
print("circuit",circuit)
simulator = cirq.Simulator()                          # Simulate
result = simulator.simulate(circuit)
statevector = result.final_state_vector
amplitudes =np.abs(statevector)
n_qubits = 3
N = 2**n_qubits  
fig, ax = plt.subplots(figsize=(10,5))
x = np.arange(N)
ax.bar(x, amplitudes, color='black', edgecolor='black')
ax.set_xticks(x)
ax.set_xlabel('Basis State Index')
ax.set_ylabel('Amplitude')
ax.set_title('3 Qubit Fourier TF of Rect Function)')
plt.grid(True)
plt.tight_layout()
plt.savefig("qft_rect_function_amplitudes.png")
plt.show()  
centered_statevector = np.fft.fftshift(statevector)
fig, axes =plt.subplots(1,2,figsize=(12,4))      
axes[0].set_ylim(0, 0.5)
axes[0].set_xlim(-1, len(state))
bar =axes[0].bar(range(len(state)),\
	np.abs(intermediate_states[0])**2, color="black")
axes[0].set_title(" Rect Function")
axes[0].set_xlabel("x")
axes[0].bar(range(len(state)),\
	np.abs(intermediate_states[0])**2, color="black")
axes[1].stem(np.abs(centered_statevector),linefmt ="k-")
plt.xlabel('Frequency index (centered)')
plt.ylabel('Amplitude magnitude')
plt.title('Centered QFT Output in Cirq')
plt.grid(True)
plt.tight_layout()                          # Avoid overlapping
plt.show()
centered_statevector = np.fft.fftshift(statevector)