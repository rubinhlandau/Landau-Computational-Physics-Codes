""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""

# ODEsympy.py: symbolic soltn of HO ODE using sympy

from sympy import *

f,g = symbols('f g',cls=Function)          # Make f a function 
t,kap,w0 = symbols('t kap w0')
f(t)
f(t).diff(t)
print("\n ODE to be solved:")
diffeq = Eq(f(t).diff(t,t) + kap*(f(t).diff(t)) + (w0*w0)*f(t))
print(diffeq)
print("\n Solution of ODE:")
ff = dsolve(diffeq,f(t))                         # Solves ODE
F = ff.subs(t,0)
print(ff)