""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""

# IntegGaussCall.py: N point Gaussian quadrature \int[a,b] f(x)dx
 
from numpy import *;  from GaussPoints import GaussPoints
Npts = 10; Ans = 0;  a = 0.;  b = 1.;  eps = 3.E-14
w = zeros(2001, float);  x = zeros(2001, float)        

def f(x):  
	return exp(x)                            
GaussPoints(Npts, a, b, x, w, eps)      #  eps: precison of pts  
for i in  range(0,Npts): Ans += f(x[i])*w[i]    
print '\n Npts =', Npts, ',   Ans =', Ans
print ' eps =',eps, ', Error =', Ans-(exp(1)-1)