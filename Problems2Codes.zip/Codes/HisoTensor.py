""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""
	 
# HisoTensor.py:  Calc binding energy of H isotooes

import tensorflow as tf; import matplotlib.pyplot as mpl 
import numpy as np
B = np.zeros(7)                                  
mP = tf.constant(938.2592)               # Proton mass in MeV/c2
mN = tf.constant(939.5527)                        # Neutron mass  
mH = tf.multiply(1.00784, 931.494028)            # H atomic mass                                            
am = tf.constant([1.007825032, 2.01401778,\         # Iso Masses
                  3.016049278, 4.026, 5.035, 6.045, 7.05])    
A = tf.constant([1,2.,3.,4.,5.,6.,7.])          # Atomic numbers
for i in range(7):
    C = mH + (i)*mN - am[i]*931.494028
    AN = A[i]
    B[i]= C/AN
    print("BN :",B[i] )
mpl.ylabel('Binding energy per nucleon (MeV)')
mpl.xlabel('Atomic mass number')
mpl.plot(A,B)
mpl.show()