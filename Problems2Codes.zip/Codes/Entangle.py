""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""

# Entangle.py: Calculate quantum entangled states

from numpy import * ; from numpy.linalg import *
nmax = 4
H = zeros((nmax,nmax),float)
XaXb = array([[0, 0, 0, 1],[0,0,1,0],[0,1,0,0],[1,0,0,0]])
YaYb = array([[0,0,0,-1],[0,0,1,0],[0,1,0,0],[-1,0,0,0]])
ZaZb = array([[1,0,0,0],[0,-1,0,0],[0,0,-1,0],[0,0,0,1]])
SaSb = XaXb + YaYb + ZbZb - 3*ZbZb             # Hamiltonian 
print('\nHamiltonian without mu^2/r^3 factor \n', SaSb, '\n')
es,ev = eig(SaSb)                    # Eigenvalues & vectors
print('Eigenvalues\n', es, '\n')
print("Eigenvectors (in columns)\n", ev, "\n")
phi1 = (ev[0,0],ev[1,0],ev[2,0],ev[3,0])   
phi4 = (ev[0,1],ev[1,1],ev[2,1],ev[3,1])  
phi3 = (ev[0,2],ev[1,2],ev[2,2],ev[3,2])
phi2 = (ev[0,3],ev[1,3],ev[2,3],ev[3,3])
basis = [phi1, phi2, phi3,phi4]                  # New basis
for i in range(0,nmax):                     # H in new basis
    for j in range(0,nmax):
       term   = dot(SaSb,basis[i])
       H[i,j] = dot(basis[j],term)
print( "Hamiltonian in Eigenvector Basis\n", H)