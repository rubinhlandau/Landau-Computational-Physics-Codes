""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""
	 
# AdvecLax.py: dvection eqnt via Lax-Wendroff scheme
# du/dt+ c*d(u**2/2)/dx=0;   u(x,t=0)=exp(-300(x-0.12)**2)  

from vpython import *
m = 100                                        
c = 1.;     dx = 1./m;    beta = 0.8          
u = [0]*(m+1);                                  
u0 = [0]*(m+1);
uf = [0]*(m+1)    
dt = beta*dx/c;
T_final = 0.5;
n = int(T_final/dt)                             # n time steps                        
graph1 = graph(width=600, height=500, xtitle = 'x', xmin=0,xmax=1,
        ymin=0, ymax=1, ytitle = 'u(x), Cyan=exact, Yellow=Numerical', 
        title='Advect Eqn: Initial (red), Exact (cyan),Numerical (yellow)')
initfn = gcurve(color = color.red);
exactfn = gcurve(color = color.cyan)
numfn = gcurve(color = color.yellow)       # Numerical solution

def plotIniExac():               # Plot initial & anal solution
   for i in range(0, m):                     
      x = i*dx 
      u0[i] = exp(-300.* (x - 0.12)**2)      # Gaussian initial
      initfn.plot(pos = (0.01*i, u0[i]) )      
      uf[i] = exp(-300.*(x - 0.12 - c*T_final)**2)  
      exactfn.plot(pos = (0.01*i, uf[i]) )
      rate(50)
plotIniExac()

def numerical():                # Finds Lax Wendroff solution
  for j in range(0, n+1):                       #  Time loop               
    for i in range(0, m - 1):                     #   x loop
        u[i + 1] = (1.-beta*beta)*u0[i+1]-(0.5*beta)*(1.-beta)*u0[i+2] 
        +(0.5*beta)*(1. + beta)*u0[i]   # Algorithm
        u[0] = 0.;     u[m-1] = 0.;    u0[i] = u[i]           
numerical()                   
for j in range(0, m-1 ):
    rate(50)
    numfn.plot(pos = (0.01*j, u[j]) )        # Plot numeric soltn