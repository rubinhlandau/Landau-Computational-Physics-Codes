""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""      

# ImageSphereVP.py: E field lines for charge + image wi VPython

from vpython import *

scene= canvas(width=500, height=500,range=100, 
	title="E of Charge in Sphere (Red Image)")
gridpts = points(radius=4, color=color.cyan)

def grid3d():
  for z in range(-60,80,20):
      for y in range (-60,80,20):
          for x in range(-60,80,20): gridpts.append(pos = (x,y,z))         
grid3d()
xp = 60;  yp = 40;  zp = 0;  a = 30;  q = 1
xx = vector(xp, yp, zp)                        # Charge location
xxp = xx*a**2/(mag(xx))**2                      # Image location
qp = -q*a/mag(xx)                                 # Image charge
ball = sphere(pos=vector(0,0,0),radius=a, opacity=0.5)
poscharge = sphere(radius=5,color=color.red, pos=vector(xp,yp,zp))
negcharge = sphere(radius=5,color=color.blue, pos=xxp)

def electricF():
    for y in range(-60,80,20):
       for z in range(-60,80,20):
          for x in range(-60,80,20):
             r = vector(x,y,z)                        
             d = vector(r-xx)                          # q to r
             dm = vector(r-xxp)
             dd = mag(d)                                
             ddp = mag(dm)                      
             if dd !=0:              
                 E1 =  d/dd**3                     # E due to q
                 E2 = -dm/ddp**3                   # E due to -q
                 E =  E1 + E2               
                 elecF = arrow(pos=r,color=color.orange) # E
                 elecF.axis = 10*E/mag(E)      # 10 x unit vector
electricF()