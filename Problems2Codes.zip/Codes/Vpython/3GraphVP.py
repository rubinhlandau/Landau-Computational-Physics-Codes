""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""      
  
# 3GraphVP.py: Vpython 3 plots, with bars, dots & curve

from vpython import *
string="blue: sin^2(x), black= cos^2(x), cyan: sin(x)*cos(x)"
graph1=graph(title=string, xtitle='x', ytitle='y', 
	background=color.white, foreground=color.black)
y1 = gcurve(color=color.blue)                         # Curve
y2 = gvbars(color=color.black)                # Vertical bars
y3 = gdots(color=color.cyan)                           # Dots
for x in arange(-5,5,0.1):                 # Range for  plots
    y1.plot(pos=(x,sin(x)**2))
    y2.plot(pos=(x,cos(x)*cos(x)/3.))
    y3.plot(pos=(x,sin(x)*cos(x)))