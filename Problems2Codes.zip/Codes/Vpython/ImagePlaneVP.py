""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""      

# ImagePlaneVP.py: E field lines, charge plus image wi VPython

from vpython import *; from numpy import *

scene =  canvas(width=500, height=500,range=100,
	title="E of Charge Left of Plane (Red Image)")
plane = box(pos=vector(0,0,0),length=2,height=130,width=130,
	color=vector(0.9,0.9,0.9),opacity=0.5)
gridpts = points(radius=4, color=color.cyan)
PlusCharge = sphere(radius=5,color=color.red,pos=vector(40,0,0))
NegCharge = sphere(radius=5,color=color.green,pos=vector(-40,0,0))

def grid3d():
  for z in range(-60,80,20):
    for y in range (-60,80,20):
      for x in range(-60,80,20): gridpts.append(pos=vector(x,y,z))          
def electricF():
    for y in range(-60,80,20):
       for z in range(-60,80,20):
          for x in range(-60,80,20):
             r = vector(x,y,z)                     
             xx = vector(40.,0,0)                     # q location
             d = vector(r-xx)                             # q to r
             dm = vector(r+xx)                           # q' to r
             dd = mag(d)                                    
             ddp = mag(dm)                      
             if(x==40 and y==0 and z==0):    continue
             if ddp !=0:              
                 E1 =  d/dd**3                       # E due to q
                 E2 = -dm/ddp**3                    # E due to -q
                 E =  E1 + E2                           
                 elecF = arrow(pos=r,color=color.orange)  
                 elecF.axis = 10*E/mag(E)      # 10 x unit vector
grid3d()
electricF()