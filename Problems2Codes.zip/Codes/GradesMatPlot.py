""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""

# GradeMatPlot.py: Matplotlib plot multi-data sets 

import pylab as p; from numpy import*
p.title('Grade Inflation')                    
p.xlabel('Years in College')
p.ylabel('GPA')
xa = array([-1, 5])                       # Horizontal line
ya = array([0, 0])                         
p.plot(xa, ya)                            # Draw horizontal
x0 = array([0, 1, 2, 3, 4])               # Data set0
y0 = array([-1.4, +1.1, 2.2, 3.3, 4.0])
p.plot(x0, y0, 'bo')                      # Blue circles
p.plot(x0, y0, 'g')                        
x1 = arange(0, 5, 1)                      # Data set 1 
y1 = array([4.0, 2.7, -1.8, -0.9, 2.6])              
p.plot(x1, y1, 'r')                                          
errTop = array([1.0, 0.3, 1.2, 0.4, 0.1]) # Asymmetric error bars
errBot = array([2.0, 0.6, 2.3, 1.8, 0.4])                    
p.errorbar(x1, y1, [errBot, errTop], fmt = 'o') # Plot error bars
p.grid(True)                                          # Grid line
p.show()          