""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""
	 
# SchCat.py: Atom undecayed => cat alive, atom decayed => dead 

import cirq; import import_ipynb
circuit = cirq.Circuit()
atom = cirq.LineQubit("atom")                       
cat = cirq.LineQubit("cat")                          
circuit.append([cirq.H(cat)])                      # Alive dead
circuit.append([cirq.CNOT(cat,atom)])    # Cat-atom interaction  
print("Entangled atom cat ")
print(circuit)                              # Entangled circuit
simu = cirq.Simulator()
resui = simu.simulate(circuit)
stvector = resui.final_state_vector
print("Entangled atom cat:", cirq.dirac_notation(stvector))
print(" ")
circuit.append([cirq.measure(atom, key="x")])
simul=cirq.Simulator()
resul = simul.simulate(circuit)
stvector = resul.final_state_vector
print("Final state atom & cat:", cirq.dirac_notation(stvector))
circuit.append([cirq.measure(cat, key="y")])
res2 = simul.run(circuit,repetitions=1)
print("Final circuit")
print(circuit)