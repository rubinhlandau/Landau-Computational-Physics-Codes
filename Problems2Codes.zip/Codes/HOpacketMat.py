""" Copyright by RH Landau, Oregon State Unv, 
                 MJ Paez,   Univ Antioquia, 2026
    From "COMPUTATIONAL PHYSICS" and "COMPUTATIONAL PROBLEMS for PHYSICS"
    by RH Landau and MJ Paez 
    Please respect copyright & acknowledge our work."""

# HOpacketMat.py: HO Wave Packet, Matplotlib Animation

from numpy import *; from matplotlib import animation
import numpy as np, matplotlib.pyplot as plt

a = 1; oneoverpi = 1.0/(sqrt(np.pi))
fig = plt.figure()                             
ax = fig.add_subplot(111,autoscale_on=False,xlim=(-5,5),
	ylim=(0,1.5))
ax.grid()                                   # Plot grid
plt.title("Wave Packet in H. O. potential")
plt.xlabel("x")
plt.ylabel (" $|\psi(x,t)|^2$")
line, = ax.plot([],[], lw=2)

def init():                                 # Base frame 
    line.set_data([],[])
    return line, 
def animate(t):                          # Call repeatedly
  y=oneoverpi*np.exp(-(x-a*np.cos(0.01*t))**2) # Plot ea 0.01*t
  line.set_data(x,y)
  return line,
x = np.arange(-5,5,0.01)                         # x range  
ani = animation.FuncAnimation(fig, animate,init_func=init,
	frames=10000, interval=10,blit=True)
plt.show()